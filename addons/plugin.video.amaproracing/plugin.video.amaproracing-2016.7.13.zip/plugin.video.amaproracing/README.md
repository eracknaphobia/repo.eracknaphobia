plugin.video.amaproracing
======================

XBMC plugin for AMA Pro Racing

This plugin was built to watch live streams and archive video of AMA Pro Racing events inside XBMC / KODI

Official Thread: http://forum.kodi.tv/showthread.php?tid=229688
