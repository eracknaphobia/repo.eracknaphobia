[![GitHub release](https://img.shields.io/github/release/eracknaphobia/plugin.video.nhlgcl.svg)](https://github.com/eracknaphobia/plugin.video.nhlgcl/releases)
![License](https://img.shields.io/badge/license-GPL%20(%3E%3D%202)-orange)
[![Contributors](https://img.shields.io/github/contributors/eracknaphobia/plugin.video.nhlgcl.svg)](https://github.com/eracknaphobia/plugin.video.nhlgcl/graphs/contributors)


Watch recaps, extended highlights, live and archived full games* with NHL TV

*Requires a valid NHL TV account to view full Live and Archived games. Blackout and other restrictions apply, including national blackouts.
